var question = ["Please explain to me a challenge you have faced?"]

